/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package psp.u3;

/**
 *
 * @author vmartinez
 */
public class A1_Numeros2 extends Thread {
    
    A1_Numeros2 (String name) {
        super(name);
    }
     
    @Override
    public void run() {
        for (int i=0; i<=100; i+=10) {
            System.out.println(this.getName() + " - Multiplos de 10: " + i);
        }
    }
    
}
