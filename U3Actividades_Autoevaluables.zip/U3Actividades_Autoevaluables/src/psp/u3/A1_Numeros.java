/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package psp.u3;

/**
 *
 * @author vmartinez
 */
public class A1_Numeros {

    public static void main(String[] args) {
        
        A1_Numeros1 hilo1 = new A1_Numeros1("hilo1");
        A1_Numeros1 hilo2 = new A1_Numeros1("hilo2");
        A1_Numeros2 hilo3 = new A1_Numeros2("hilo3");
        hilo1.start();
        hilo2.start();
        hilo3.start();
    }
}
