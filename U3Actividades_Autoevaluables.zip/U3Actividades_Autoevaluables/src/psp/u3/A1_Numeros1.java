/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package psp.u3;

/**
 *
 * @author vmartinez
 */
public class A1_Numeros1 extends Thread {

    A1_Numeros1(String name) {
        super(name);
    }
    
    // suma de los números divisibles entre 5 que se encuentran en un rango de 100 al 1000
    @Override
    public void run() {
        int acumulador = 0;
        for (int i = 100; i <= 1000; i++) {
            if (i % 5 == 0) {
                acumulador += i;
            }
        }
        System.out.println(this.getName() + " - Suma de los multiplos de 5 entre 100 y 1000: " + acumulador);
    }

}
