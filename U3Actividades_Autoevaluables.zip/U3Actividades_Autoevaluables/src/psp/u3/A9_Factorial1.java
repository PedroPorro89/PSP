/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package psp.u3;

/**
 *
 * @author vmartinez
 */
public class A9_Factorial1 implements Runnable {

    private final int n;
    private final String name;
    
    public A9_Factorial1(int n) {
        this.n = n;
        this.name = "Factorial"+ n;
    }

    
    @Override
    public void run() {
        int factorial = 1;
        for (int i = n; i > 0; i--) {
            factorial = factorial * i;
        }
        System.out.printf("%s: Factorial de %d: %d\n", name, n, factorial);
    }
    
    
}
