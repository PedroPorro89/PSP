package psp.u3;

/**
 *
 * @author vmartinez
 */
public class A9_Factorial {

    public static void main(String[] args) {

        for (String number : args) {
            A9_Factorial1 r = new A9_Factorial1(Integer.parseInt(number));
            
            Thread h1 = new Thread(r);
            h1.start();
        }
    }
}
